In order to run this animation,

1. open the group_2_assignment4.pde file 
	and press run.

2. The image will display in another window.