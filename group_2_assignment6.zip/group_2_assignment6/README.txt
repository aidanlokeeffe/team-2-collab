To start this program open the ".pde" file named "group2_assignment6.pde".

After that click the run button to start the program.

The user may control the program by clicking on the two buttons on the left and right side of the screen.
These buttons release NH3 and HCl gas particles, respectively, and the particles will bounce around the environment
constantly until the two collide and form a NH4Cl solid.

The user can click and hold over the button to release a constant flow of both types of gas particles.