This program is a simple 3D animation meeting the specs for assignment 5.

To run the program, simply open the program file "group_2_assignment5.pde" and click the play button.